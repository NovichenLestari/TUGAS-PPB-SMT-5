package com.example.aplication;


import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;

public class MenuAdapterPemesanan extends RecyclerView.Adapter<MenuAdapterPemesanan.MenuAdapterViewHolder>{

    Context context;
    ArrayList<Menus_Pemesanan> listMenu;
    FirebaseAuth mAuth;

    public MenuAdapterPemesanan(Context ctx, ArrayList<Menus_Pemesanan> list) {
        this.context = ctx;
        this.listMenu = list;
    }

    @Override
    public MenuAdapterViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_menu_pemesanan, parent, false);
        return new MenuAdapterViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final MenuAdapterViewHolder holder, int position) {
        Menus_Pemesanan now = listMenu.get(position);
        holder.tv_harga.setText(now.getHarga());
        holder.tv_produk.setText(now.getProduk());
        holder.tv_jumlah.setText(now.getJumlah());
    }

    @Override
    public int getItemCount() {
        return this.listMenu.size();
    }

    public class MenuAdapterViewHolder extends RecyclerView.ViewHolder{

        TextView tv_harga, tv_produk, tv_jumlah;

        public MenuAdapterViewHolder(final View itemView) {
            super(itemView);
            tv_harga = (TextView) itemView.findViewById(R.id.tv_harga);
            tv_produk = (TextView) itemView.findViewById(R.id.tv_produk);
            tv_jumlah = (TextView) itemView.findViewById(R.id.tv_jumlah);
        }
    }

    public void setData(ArrayList<Menus_Pemesanan> arr) {
        this.listMenu = arr;
        notifyDataSetChanged();
    }
}
